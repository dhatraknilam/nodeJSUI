var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('chatbot', { title: 'Solid Edge chatbot' });
});

router.post('/ask', function(req, res, next) {
    console.log("working");
    res.status(200).send({msg: 'India is a rich, diverse land of various cultures, languages, religions, food, etc. As citizens of India, everyone must have learnt about the history of India and all its features that make the country incredible.  In addition to all that you know about the country, here are a few sample paragraphs on India to help you understand how to structure and write one on your own.'});
  });

module.exports = router;
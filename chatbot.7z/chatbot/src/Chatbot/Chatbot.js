import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios'
import './Chatbot.css'
// import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

const Chatbot = () => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSend = async() => {
        if (input.trim()) {
            setMessages([...messages, { text: input, sender: 'user' }]);
            setInput('');

            // Simulate a bot response
           let response = await axios.post('http://localhost:3000/chatbot/ask',{message: input})
           console.log(response);
                           setMessages(messages => [...messages, { text: response.data.msg}]);

            // setTimeout(() => {
            //     setMessages(messages => [...messages, { text: response.data.msg}]);

            //     // setMessages(messages => [...messages, { text: "India is a rich, diverse land of various cultures, languages, religions, food, etc. As citizens of India, everyone must have learnt about the history of India and all its features that make the country incredible.  In addition to all that you know about the country, here are a few sample paragraphs on India to help you understand how to structure and write one on your own.", sender: 'bot' }]);
            // }, 1000);


        }
    };

    return (
        <div className="chatbot-container py-2">
                  <div className='display-3 text-center'>ChatBot</div>

            <div className="card">
                <div className="card-body chatbot-messages" style={{ height: '70vh', overflowY: 'auto' }}>
                    {messages.map((message, index) => (
                        <div key={index} className={`mb-2 ${message.sender === 'user' ? 'text-end' : ''}`}>
                            <div className={`badge text-wrap fs-5 ${message.sender === 'user' ? 'bg-primary' : 'bg-secondary'}`} style={{background:'inherit'}}>
                                {message.text}
                            </div>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>
                <div className="container fixed-bottom my-3">
                    <div className="input-group">
                        <input
                            type="text"
                            className="form-control"
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyPress={e => e.key === 'Enter' && handleSend()}
                            placeholder="Type your message..."
                        />
                        <button className="btn btn-primary" onClick={handleSend}>Send</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Chatbot;

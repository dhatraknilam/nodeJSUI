import React from 'react';
import Chatbot from './Chatbot/Chatbot';
import './App.css';
function App() {
  return (
    <div className="App">
      <Chatbot />
    </div>
  );
}

export default App;
 